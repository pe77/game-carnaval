window.onload = () => {
    var game = new GameBase.Game();
}